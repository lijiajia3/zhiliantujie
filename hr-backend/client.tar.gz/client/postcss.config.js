// client/postcss.config.js
module.exports = {
    plugins: {
      autoprefixer: {}
    }
  };