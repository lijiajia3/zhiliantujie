import React from 'react';


const ResumeAnalysisPage = ({ showChart, file }) => {
  return (
    <div>
      {}
      <div>图表组件已移除</div>
    </div>
  );
};

export default ResumeAnalysisPage;